// src/components/TaskBoard.jsx
import React, { useEffect, useState } from "react";
import { db } from "../data/db.js";
import { useAuth } from "../context/AuthContext.jsx";
import { Trash2 } from "lucide-react";

export default function TaskBoard() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [status, setStatus] = useState("Aberta");
  const [priority, setPriority] = useState("Normal");
  const { user } = useAuth();

  const loadTasks = async () => {
    const data = await db.tasks.toArray();
    setTasks(data);
  };

  useEffect(() => {
    if (user) loadTasks();
  }, [user]);

  const addTask = async () => {
    if (!title.trim()) return;

    await db.tasks.add({
      title: title.trim(),
      status,
      priority,
    });

    setTitle("");
    setStatus("Aberta");
    setPriority("Normal");
    loadTasks();
  };

  const deleteTask = async (id) => {
    if (!window.confirm("Excluir esta tarefa?")) return;
    await db.tasks.delete(id);
    loadTasks();
  };

  if (!user) return null;

  return (
    <div className="bg-neutral-800 p-4 rounded-xl">
      <h2 className="text-xl font-semibold mb-3">Tarefas</h2>

      {/* FORMULÁRIO COM STATUS E PRIORIDADE */}
      <div className="GRID grid-cols-1 md:grid-cols-4 gap-2 mb-4">
        <input
          className="p-2 rounded bg-neutral-900 border border-neutral-700 text-sm"
          placeholder="Título da tarefa..."
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && addTask()}
        />
        <select
          className="p-2 rounded bg-neutral-900 border border-neutral-700 text-sm"
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          <option value="Aberta">Aberta</option>
          <option value="Em andamento">Em andamento</option>
          <option value="Concluída">Concluída</option>
        </select>
        <select
          className="p-2 rounded bg-neutral-900 border border-neutral-700 text-sm"
          value={priority}
          onChange={(e) => setPriority(e.target.value)}
        >
          <option value="Alta">Alta</option>
          <option value="Normal">Normal</option>
          <option value="Baixa">Baixa</option>
        </select>
        <button
          onClick={addTask}
          className="bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded text-white text-sm font-medium"
        >
          Adicionar
        </button>
      </div>

      {/* LISTA DE TAREFAS COM BADGES */}
      <ul className="space-y-2">
        {tasks.length === 0 ? (
          <li className="text-neutral-500 italic text-sm text-center py-4">
            Nenhuma tarefa cadastrada.
          </li>
        ) : (
          tasks.map((t) => (
            <li
              key={t.id}
              className="flex items-center justify-between bg-neutral-900 p-3 rounded border border-neutral-700"
            >
              <div className="flex-1">
                <span className="font-medium text-neutral-100">{t.title}</span>
                <div className="flex gap-2 mt-1">
                  <span
                    className={`inline-block px-2 py-1 rounded text-xs font-medium ${
                      t.status === "Concluída"
                        ? "bg-green-900 text-green-300"
                        : t.status === "Em andamento"
                        ? "bg-yellow-900 text-yellow-300"
                        : "bg-blue-900 text-blue-300"
                    }`}
                  >
                    {t.status}
                  </span>
                  <span
                    className={`inline-block px-2 py-1 rounded text-xs font-medium ${
                      t.priority === "Alta"
                        ? "bg-red-900 text-red-300"
                        : t.priority === "Normal"
                        ? "bg-orange-900 text-orange-300"
                        : "bg-gray-700 text-gray-300"
                    }`}
                  >
                    {t.priority}
                  </span>
                </div>
              </div>

              <button
                onClick={() => deleteTask(t.id)}
                className="text-red-400 hover:text-red-300 p-1"
                title="Excluir tarefa"
              >
                <Trash2 size={16} />
              </button>
            </li>
          ))
        )}
      </ul>
    </div>
  );
}