// src/components/ProjectTable.jsx
import React, { useEffect, useState } from "react";
import { db } from "../data/db.js";
import { useAuth } from "../context/AuthContext.jsx";
import { Trash2 } from "lucide-react";

export default function ProjectTable() {
  const [projects, setProjects] = useState([]);
  const [newName, setNewName] = useState("");
  const [newStatus, setNewStatus] = useState("Novo");
  const [newPriority, setNewPriority] = useState("Média");
  const { user } = useAuth();

  const loadProjects = async () => {
    const data = await db.projects.toArray();
    setProjects(data);
  };

  useEffect(() => {
    if (user) loadProjects();
  }, [user]);

  const addProject = async () => {
    if (!newName.trim()) return;

    await db.projects.add({
      name: newName.trim(),
      status: newStatus,
      priority: newPriority,
    });

    setNewName("");
    setNewStatus("Novo");
    setNewPriority("Média");
    loadProjects();
  };

  const deleteProject = async (id) => {
    if (!window.confirm("Excluir projeto e TODAS as suas tarefas?")) return;
    await db.tasks.where({ projectId: id }).delete();
    await db.projects.delete(id);
    loadProjects();
  };

  if (!user) return null;

  return (
    <div className="bg-neutral-800 p-4 rounded-xl">
      <h2 className="text-xl font-semibold mb-3">Projetos</h2>

      {/* FORMULÁRIO DE ADIÇÃO COM STATUS E PRIORIDADE */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-2 mb-4">
        <input
          className="p-2 rounded bg-neutral-900 border border-neutral-700 text-sm"
          placeholder="Nome do projeto..."
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && addProject()}
        />
        <select
          className="p-2 rounded bg-neutral-900 border border-neutral-700 text-sm"
          value={newStatus}
          onChange={(e) => setNewStatus(e.target.value)}
        >
          <option value="Novo">Novo</option>
          <option value="Em andamento">Em andamento</option>
          <option value="Concluído">Concluído</option>
        </select>
        <select
          className="p-2 rounded bg-neutral-900 border border-neutral-700 text-sm"
          value={newPriority}
          onChange={(e) => setNewPriority(e.target.value)}
        >
          <option value="Alta">Alta</option>
          <option value="Média">Média</option>
          <option value="Baixa">Baixa</option>
        </select>
        <button
          onClick={addProject}
          className="bg-green-600 hover:bg-green-500 px-4 py-2 rounded text-white text-sm font-medium"
        >
          Adicionar
        </button>
      </div>

      {/* TABELA DE PROJETOS */}
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left border-b border-neutral-700">
            <th>Nome</th>
            <th>Status</th>
            <th>Prioridade</th>
            <th className="w-12"></th>
          </tr>
        </thead>
        <tbody>
          {projects.length === 0 ? (
            <tr>
              <td colSpan="4" className="text-center py-3 text-neutral-500 italic">
                Nenhum projeto cadastrado.
              </td>
            </tr>
          ) : (
            projects.map((p) => (
              <tr key={p.id} className="border-b border-neutral-700">
                <td className="font-medium">{p.name}</td>
                <td>
                  <span
                    className={`inline-block px-2 py-1 rounded text-xs font-medium ${
                      p.status === "Concluído"
                        ? "bg-green-900 text-green-300"
                        : p.status === "Em andamento"
                        ? "bg-yellow-900 text-yellow-300"
                        : "bg-blue-900 text-blue-300"
                    }`}
                  >
                    {p.status}
                  </span>
                </td>
                <td>
                  <span
                    className={`inline-block px-2 py-1 rounded text-xs font-medium ${
                      p.priority === "Alta"
                        ? "bg-red-900 text-red-300"
                        : p.priority === "Média"
                        ? "bg-orange-900 text-orange-300"
                        : "bg-gray-700 text-gray-300"
                    }`}
                  >
                    {p.priority}
                  </span>
                </td>
                <td>
                  <button
                    onClick={() => deleteProject(p.id)}
                    className="text-red-400 hover:text-red-300"
                    title="Excluir projeto"
                  >
                    <Trash2 size={16} />
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}