// src/components/ProjectTable.jsx
import React, { useEffect, useState } from "react";
import { db } from "../data/db.js";
import { useAuth } from "../context/AuthContext.jsx";
import { Trash2, Check, X } from "lucide-react";

export default function ProjectTable() {
  const [projects, setProjects] = useState([]);
  const [newName, setNewName] = useState("");
  const [newStatus, setNewStatus] = useState("Novo");
  const [newPriority, setNewPriority] = useState("Média");
  const [editingId, setEditingId] = useState(null);
  const [editName, setEditName] = useState("");
  const [editStatus, setEditStatus] = useState("");
  const [editPriority, setEditPriority] = useState("");
  const { user } = useAuth();

  const loadProjects = async () => {
    const data = await db.projects.toArray();
    setProjects(data);
  };

  useEffect(() => {
    if (user) loadProjects();
  }, [user]);

  const addProject = async () => {
    if (!newName.trim()) return;
    await db.projects.add({ name: newName.trim(), status: newStatus, priority: newPriority });
    setNewName("");
    setNewStatus("Novo");
    setNewPriority("Média");
    loadProjects();
  };

  const deleteProject = async (id) => {
    if (!window.confirm("Excluir projeto e TODAS as suas tarefas?")) return;
    await db.tasks.where({ projectId: id }).delete();
    await db.projects.delete(id);
    loadProjects();
  };

  // INICIAR EDIÇÃO
  const startEdit = (project) => {
    setEditingId(project.id);
    setEditName(project.name);
    setEditStatus(project.status);
    setEditPriority(project.priority);
  };

  // CANCELAR EDIÇÃO
  const cancelEdit = () => {
    setEditingId(null);
    setEditName("");
    setEditStatus("");
    setEditPriority("");
  };

  // SALVAR EDIÇÃO
  const saveEdit = async () => {
    if (!editName.trim()) return;
    await db.projects.update(editingId, {
      name: editName.trim(),
      status: editStatus,
      priority: editPriority,
    });
    cancelEdit();
    loadProjects();
  };

  if (!user) return null;

  return (
    <div className="bg-neutral-800 p-4 rounded-xl">
      <h2 className="text-xl font-semibold mb-3">Projetos</h2>

      {/* FORMULÁRIO DE NOVA TAREFA */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-2 mb-4">
        <input
          className="p-2 rounded bg-neutral-900 border border-neutral-700 text-sm"
          placeholder="Nome do projeto..."
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && addProject()}
        />
        <select
          className="p-2 rounded bg-neutral-900 border border-neutral-700 text-sm"
          value={newStatus}
          onChange={(e) => setNewStatus(e.target.value)}
        >
          <option value="Novo">Novo</option>
          <option value="Em andamento">Em andamento</option>
          <option value="Concluído">Concluído</option>
        </select>
        <select
          className="p-2 rounded bg-neutral-900 border border-neutral-700 text-sm"
          value={newPriority}
          onChange={(e) => setNewPriority(e.target.value)}
        >
          <option value="Alta">Alta</option>
          <option value="Média">Média</option>
          <option value="Baixa">Baixa</option>
        </select>
        <button
          onClick={addProject}
          className="bg-green-600 hover:bg-green-500 px-4 py-2 rounded text-white text-sm font-medium"
        >
          Adicionar
        </button>
      </div>

      {/* TABELA DE PROJETOS COM EDIÇÃO INLINE */}
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left border-b border-neutral-700">
            <th>Nome</th>
            <th>Status</th>
            <th>Prioridade</th>
            <th className="w-20"></th>
          </tr>
        </thead>
        <tbody>
          {projects.length === 0 ? (
            <tr>
              <td colSpan="4" className="text-center py-3 text-neutral-500 italic">
                Nenhum projeto cadastrado.
              </td>
            </tr>
          ) : (
            projects.map((p) => (
              <tr key={p.id} className="border-b border-neutral-700">
                {editingId === p.id ? (
                  /* MODO EDIÇÃO */
                  <>
                    <td>
                      <input
                        className="w-full p-1 rounded bg-neutral-800 border border-neutral-600 text-sm"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && saveEdit()}
                        autoFocus
                      />
                    </td>
                    <td>
                      <select
                        className="w-full p-1 rounded bg-neutral-800 border border-neutral-600 text-sm"
                        value={editStatus}
                        onChange={(e) => setEditStatus(e.target.value)}
                      >
                        <option value="Novo">Novo</option>
                        <option value="Em andamento">Em andamento</option>
                        <option value="Concluído">Concluído</option>
                      </select>
                    </td>
                    <td>
                      <select
                        className="w-full p-1 rounded bg-neutral-800 border border-neutral-600 text-sm"
                        value={editPriority}
                        onChange={(e) => setEditPriority(e.target.value)}
                      >
                        <option value="Alta">Alta</option>
                        <option value="Média">Média</option>
                        <option value="Baixa">Baixa</option>
                      </select>
                    </td>
                    <td className="flex gap-1">
                      <button
                        onClick={saveEdit}
                        className="text-green-400 hover:text-green-300 p-1"
                        title="Salvar"
                      >
                        <Check size={16} />
                      </button>
                      <button
                        onClick={cancelEdit}
                        className="text-neutral-400 hover:text-neutral-300 p-1"
                        title="Cancelar"
                      >
                        <X size={16} />
                      </button>
                    </td>
                  </>
                ) : (
                  /* MODO VISUALIZAÇÃO */
                  <>
                    <td className="font-medium cursor-pointer" onClick={() => startEdit(p)}>
                      {p.name}
                    </td>
                    <td>
                      <span
                        className={`inline-block px-2 py-1 rounded text-xs font-medium cursor-pointer ${
                          p.status === "Concluído"
                            ? "bg-green-900 text-green-300"
                            : p.status === "Em andamento"
                            ? "bg-yellow-900 text-yellow-300"
                            : "bg-blue-900 text-blue-300"
                        }`}
                        onClick={() => startEdit(p)}
                      >
                        {p.status}
                      </span>
                    </td>
                    <td>
                      <span
                        className={`inline-block px-2 py-1 rounded text-xs font-medium cursor-pointer ${
                          p.priority === "Alta"
                            ? "bg-red-900 text-red-300"
                            : p.priority === "Média"
                            ? "bg-orange-900 text-orange-300"
                            : "bg-gray-700 text-gray-300"
                        }`}
                        onClick={() => startEdit(p)}
                      >
                        {p.priority}
                      </span>
                    </td>
                    <td>
                      <button
                        onClick={() => deleteProject(p.id)}
                        className="text-red-400 hover:text-red-300 p-1"
                        title="Excluir"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </>
                )}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}