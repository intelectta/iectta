
🌟 Stellar-Collab
Sistema gratuito de **gerenciamento de projetos** em React + Vite + Tailwind, com **modo dark**, **autenticação local**, **armazenamento IndexedDB (Dexie.js)** e **temas coloridos**.

## 🔧 Requisitos
- Node.js 18+
- NPM

## 🚀 Como iniciar
```bash
npm install
npm run dev